Font usage: Demo only
Font by: Roland Huse
Distributed by: Font Monger

This font may not be used without permission. This font is for demo purposes only.


Without Font Premission:
You may not edit this font
You may not rename this font
You may not repackage, distribute, or sale this font
You may not use this font in multimeda, tv, applications, video games, or film.


For a commercial use license visit:
http://www.fontmonger.com


For accents, european, and special characters contact: info@fontmonger.com

